<template>
    <div>
        <header class="p-4 bg-gray-800 text-white">
            <h1 class="text-2xl">Road Trip Planner</h1>
        </header>
        <main class="p-4">
            <slot />
        </main>
    </div>
</template>

<script setup>
</script>
